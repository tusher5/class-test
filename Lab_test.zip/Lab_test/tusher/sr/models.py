from django.db import models

# Create your models here.
class Course(models.Model):
    course_code = models.IntegerField()
    course_title = models.CharField(max_length=20)
    credit =  models.FloatField()
    def __str__(self):
        return f"{self.course_code}: {self.course_title} : {self.credit}"
class Teacher(models.Model):
    first_name = models.CharField(max_length=12)
    last_name = models.CharField(max_length=12)
    
    affiliation = models.CharField(max_length=20)
    course = models.ForeignKey(Course,on_delete=models.CASCADE)
def __str__(self):
        return f"{self.first_name}: {self.last_name} : {self.affiliation}"
    
class Student(models.Model):
     registration_number =models.IntegerField()
     roll_number = models.IntegerField()
     first_name = models.CharField(max_length=20)
     last_name = models.CharField(max_length=20)
     date_of_birth = models.DateField()
     course = models.ManyToManyField(Course, blank=True , related_name="total_student")

     def __str__(self):
       return f"{(self.first_name)} : ({self.last_name}) : ({self.registration_number}) : ({self.roll_number}): ({self.date_of_birth})" 

from django.contrib import admin
from .models import *
# Register your models here.
class CourseAdmin(admin.ModelAdmin):
    list_display = ("course_code", "course_title", "credit")
class TeacherAdmin(admin.ModelAdmin):
    list_display = ("first_name", "last_name", "affiliation")
class StudentAdmin(admin.ModelAdmin):
     list_display = ("first_name", "last_name","registration_number")
admin.site.register(Course,CourseAdmin)
admin.site.register(Teacher,TeacherAdmin)
admin.site.register(Student,StudentAdmin)